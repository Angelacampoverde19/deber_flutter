import 'package:deber_flutter/main.dart';

abstract class TaskEvent {}

class AddTaskEvent extends TaskEvent {
  final Task task;
  AddTaskEvent(this.task);
}

class CompleteTaskEvent extends TaskEvent {
  final Task task;
  CompleteTaskEvent(this.task);
}

class DeleteTaskEvent extends TaskEvent {
  final Task task;
  DeleteTaskEvent(this.task);
}
