import 'dart:async';
import 'package:deber_flutter/task_event.dart';
import 'package:meta/meta.dart';



class TaskBloc extends Bloc<TaskEvent, TaskState> {
  TaskBloc() : super(TaskInitial());

  @override
  Stream<TaskState> mapEventToState(TaskEvent event) async* {
    if (event is AddTaskEvent) {
      yield* _mapAddTaskToState(event as AddTaskEvent);
    } else if (event is CompleteTaskEvent) {
      yield* _mapCompleteTaskToState(event as CompleteTaskEvent);
    } else if (event is DeleteTaskEvent) {
      yield* _mapDeleteTaskToState(event as DeleteTaskEvent);
    }
  }

  Stream<TaskState> _mapAddTaskToState(AddTaskEvent event) async* {
    // Lógica para agregar una tarea
    yield TaskAddedState(task: event.task, tasks: state.tasks + [event.task]);
  }

  Stream<TaskState> _mapCompleteTaskToState(CompleteTaskEvent event) async* {
    // Lógica para marcar una tarea como completada
    List<Task> updatedTasks = state.tasks.map((task) {
      return task.id == event.task.id ? task.copyWith(completed: true) : task;
    }).toList();
    yield TaskCompletedState(task: event.task, tasks: updatedTasks);
  }

  Stream<TaskState> _mapDeleteTaskToState(DeleteTaskEvent event) async* {
    // Lógica para eliminar una tarea
    List<Task> updatedTasks = state.tasks.where((task) => task.id != event.task.id).toList();
    yield TaskDeletedState(task: event.task, tasks: updatedTasks);
  }
}

mixin TaskState {
}

mixin TaskEvent {
}
