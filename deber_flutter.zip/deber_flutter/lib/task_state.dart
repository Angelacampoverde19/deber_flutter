part of 'task_bloc.dart';

abstract class TaskState {
  final List<Task> tasks;

  TaskState(this.tasks);
}

mixin Task {
}

class TaskInitial extends TaskState {
  TaskInitial() : super([]);
}

class TaskAddedState extends TaskState {
  final Task task;

  TaskAddedState({required this.task, required List<Task> tasks}) : super(tasks);
}

class TaskCompletedState extends TaskState {
  final Task task;

  TaskCompletedState({required this.task, required List<Task> tasks}) : super(tasks);
}

class TaskDeletedState extends TaskState {
  final Task task;

  TaskDeletedState({required this.task, required List<Task> tasks}) : super(tasks);
}
