import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() {
  runApp(MyApp());
}

class Task {
  final int id;
  final String description;
  final bool completed;

  Task({required this.id, required this.description, this.completed = false});

  Task copyWith({bool? completed}) {
    return Task(id: id, description: description, completed: completed ?? this.completed);
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: BlocProvider(
        create: (context) => TaskBloc(),
        child: TaskListScreen(),
      ),
    );
  }

  BlocProvider({required Function(dynamic context) create, required TaskListScreen child}) {}
}

class TaskListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Task List')),
      body: BlocBuilder<TaskBloc, TaskState>(
        builder: (context, state) {
          if (state is TaskInitial) {
            return Center(child: Text('No tasks yet.'));
          } else {
            List<Task> tasks = state.tasks;
            return ListView.builder(
              itemCount: tasks.length,
              itemBuilder: (context, index) {
                Task task = tasks[index];
                return ListTile(
                  title: Text(task.description),
                  leading: Checkbox(
                    value: task.completed,
                    onChanged: (value) {
                      BlocProvider.of<TaskBloc>(context).add(CompleteTaskEvent(task));
                    },
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () {
                      BlocProvider.of<TaskBloc>(context).add(DeleteTaskEvent(task));
                    },
                  ),
                );
              },
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showAddTaskDialog(context);
        },
        child: Icon(Icons.add),
      ),
    );
  }

  void _showAddTaskDialog(BuildContext context) {
    TextEditingController controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add Task'),
          content: TextField(controller: controller),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                String description = controller.text.trim();
                if (description.isNotEmpty) {
                  Task newTask = Task(id: DateTime.now().millisecondsSinceEpoch, description: description);
                  BlocProvider.of<TaskBloc>(context).add(AddTaskEvent(newTask));
                  Navigator.of(context).pop();
                }
              },
              child: Text('Add'),
            ),
          ],
        );
      },
    );
  }
}

